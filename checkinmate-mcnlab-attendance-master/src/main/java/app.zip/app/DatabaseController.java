package app.database;

import app.database.history.HistoryManage;
import app.system.ResponseCode;
import app.system.TimeManage;
import app.userSession.SessionManage;

import java.sql.Time;

/**
 * 데이터베이스 관련 로직을 총괄하는 컨트롤러 클래스입니다.
 * 현재는 파일 기반으로 데이터를 처리하지만, 향후 JPA를 이용한 RDB 연동을 위해 설계되었습니다.
 */
public class DatabaseController {
    // 각 관리 모듈에 대한 정적(static) 참조 변수들
    public static SessionManage sessionManage; // 사용자 세션 관리를 담당
    public static HistoryManage historyManage; // 사용자 활동 이력(로그) 관리를 담당
    public static FileManage fileManage;       // 파일 입출력을 통한 데이터 영속성 관리를 담당

    // 응답 코드를 저장하기 위한 인스턴스 변수
    ResponseCode code;

    /* 이 클래스의 책임:
     *
     * - 이 클래스는 향후 RDB가 연결될 때 각 요청에 대한 JPA 코드를 작성하는 데 사용됩니다.
     * - 현재의 파일 기반 코드를 제거하고 데이터베이스 제어 코드로 변경할 수 있습니다.
     */

    /**
     * 사용자의 제출(submit) 요청을 처리합니다.
     * 흐름: 제출 요청 접수 -> 세션 상태 확인 -> 결과에 따른 로그 기록 (현재는 파일, 향후 DB)
     *
     * @param id 제출을 요청한 사용자의 고유 ID
     * @return 처리 결과에 따른 ResponseCode (성공 시 OK, 사용자를 찾을 수 없을 시 NotFound)
     */
    public ResponseCode submit(Long id) {
        // 1. SessionManage를 통해 제출 요청을 처리하고 결과 코드를 받습니다.
        code = sessionManage.submit(id);

        // 2. 반환된 응답 코드에 따라 분기 처리
        switch (code.getCode()) {
            // 성공적인 제출 시, 이력(History)을 기록합니다.
            case 211: // "First Submit" - 사용자의 첫 제출인 경우
                HistoryManage.createSession(id); // 새로운 세션 생성 이력을 기록합니다.
                break;
            case 212: // "Extend Submit" - 기존 세션을 연장하는 경우
                HistoryManage.extendSession(id); // 세션 연장 이력을 기록합니다.
                break;
            case 213: // "Renewed Submit" - 만료된 세션을 갱신하는 경우
                // 이전 세션을 종료 처리하고, 새로운 세션을 생성합니다.
                HistoryManage.closeSession(id, SessionManage.getThisSessionTime(id)); // 이전 세션 종료 이력 기록
                HistoryManage.createSession(id); // 새 세션 생성 이력 기록
                break;
            case 404: // "Can't Find User (Not Found)" - 해당 ID의 사용자를 찾을 수 없는 경우
                return ResponseCode.NotFound; // NotFound 응답 코드를 즉시 반환합니다.
            default:
                // 그 외의 다른 코드(예: 에러 코드)는 현재 로직에서 별도로 처리하지 않고 무시합니다.
                break;
        }

        // 위 switch문에서 404가 아닌 성공적인 처리가 완료된 경우, OK 응답 코드를 반환합니다.
        return ResponseCode.OK;
    }

    /**
     * 현재 세션 상태를 동기화하고 갱신합니다.
     * 예를 들어, 만료된 세션을 정리하는 등의 작업을 수행합니다.
     */
    public void sync() {
        sessionManage.refreshSession();
        // TODO - 향후 DB와의 데이터 동기화 로직이 추가될 부분입니다.
    }

    /**
     * 현재 메모리에 있는 사용자 정보를 파일로 저장(export)합니다.
     * 프로그램 종료 시 데이터 보존을 위해 사용될 수 있습니다.
     */
    public void saveUserInfo(){
        fileManage.exportUsers();
    }

    /**
     * 현재 세션 상태 정보를 파일로 저장합니다.
     */
    public void saveStatus(){
        fileManage.saveStatus();
    }

    // --- 생성자 ---

    /**
     * 기본 생성자입니다.
     * SessionManage 인스턴스 없이 초기화하며, 다른 생성자를 null 값으로 호출합니다.
     */
    public DatabaseController() {
        this(null);
    }

    /**
     * SessionManage 인스턴스를 주입받는 생성자입니다.
     * 이 컨트롤러가 사용할 모든 관리 모듈(HistoryManage, FileManage)을 초기화합니다.
     *
     * @param sessionManage 외부에서 생성된 SessionManage 인스턴스
     */
    public DatabaseController(SessionManage sessionManage) {
        DatabaseController.sessionManage = sessionManage;
        historyManage = new HistoryManage();
        fileManage = new FileManage(historyManage);
    }
}
