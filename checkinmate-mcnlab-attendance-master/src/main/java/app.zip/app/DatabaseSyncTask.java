package app.database;

import app.system.TimeManage;

/**
 * 데이터베이스 동기화 작업을 별도의 스레드에서 수행하기 위한 클래스입니다.
 * Runnable 인터페이스를 구현하여, ScheduledExecutorService와 같은 스레드 스케줄러에 의해 주기적으로 실행될 수 있습니다.
 */
public class DatabaseSyncTask implements Runnable {

    // 데이터베이스 관련 로직을 실제로 처리할 컨트롤러 인스턴스
    private final DatabaseController controller;

    /**
     * DatabaseSyncTask 생성자입니다.
     * 동기화 작업을 위임할 DatabaseController 인스턴스를 주입받습니다.
     * @param controller 데이터베이스 컨트롤러 객체
     */
    public DatabaseSyncTask(DatabaseController controller) {
        this.controller = controller;
    }

    /**
     * 스레드가 실행될 때 호출되는 메서드입니다. (Runnable 인터페이스의 run 메서드 구현)
     * 실제 동기화 작업을 수행합니다.
     */
    @Override
    public void run() {
        // 동기화 시작을 알리는 로그 출력
        System.out.println(TimeManage.getTimeByString() + "[DatabaseSyncTask] start sync database...");

        // 컨트롤러에 동기화 요청을 위임합니다.
        controller.sync();

        // 동기화 완료를 알리는 로그 출력
        System.out.println(TimeManage.getTimeByString() + "[DatabaseSyncTask] database sync complete.");
    }

    /**
     * 다음 동기화 시점까지 남은 시간을 분(minute) 단위로 계산합니다.
     * 이 메서드는 동기화 주기를 매 10분 (예: 05분, 15분, 25분...)으로 맞추기 위해
     * 스케줄러의 초기 지연(initial delay) 시간을 설정하는 데 사용됩니다.
     * * @return 다음 동기화까지 남은 시간 (분)
     */
    public static long calculateInitialDelayForSync() {
        // 현재 시간의 '분' 정보를 가져옵니다.
        long minutes = java.time.LocalTime.now().getMinute();

        // 다음 동기화 시점(현재 시간에서 가장 가까운 xx시 05분, 15분, 25분, ...)까지 남은 시간을 계산합니다.
        // 예:
        // - 현재 01분 -> (55 - 1) % 10 = 4분 후 (05분에 실행)
        // - 현재 05분 -> minutes % 10 == 5 이므로 0분 후 (즉시 실행)
        // - 현재 08분 -> (55 - 8) % 10 = 7분 후 (15분에 실행)
        // - 현재 56분 -> (55 - 56) % 10 = -1 % 10 이지만, Java의 % 연산자는 피연산자 부호를 따르므로,
        //   (55 - minutes)가 음수가 될 경우를 대비해 (55 - minutes + 10) % 10 과 같이 사용하는 것이 더 안전할 수 있습니다.
        //   하지만 여기서는 (55 - 56) = -1 이 되고, (-1 % 10)의 결과가 -1이므로 의도와 다를 수 있습니다.
        //   더 명확한 로직은 (5 - (minutes % 10) + 10) % 10 입니다.
        //   예: minutes=1 -> (5-1+10)%10 = 4. minutes=8 -> (5-8+10)%10 = 7. minutes=6 -> (5-6+10)%10=9.
        //   현재 코드는 분이 55분을 초과할 때 예상과 다르게 동작할 수 있으나, 주어진 로직을 그대로 주석처리합니다.
        long nextSyncInMinutes = (minutes % 10 == 5) ? 0 : (55 - minutes) % 10;

        // 계산된 남은 시간을 로그로 출력합니다.
        System.out.println(TimeManage.getTimeByString() + "[DatabaseSyncTask] Remain Min for Next Database Sync: " + nextSyncInMinutes);

        return nextSyncInMinutes;
    }
}
