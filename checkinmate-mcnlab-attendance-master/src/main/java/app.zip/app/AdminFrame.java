package app.adminPage;

import javax.swing.*;

public class AdminFrame extends JFrame {
}
